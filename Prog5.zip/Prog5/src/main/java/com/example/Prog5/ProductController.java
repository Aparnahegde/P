package com.example.Prog5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/product")
public class ProductController {
	List <Product> plist=new ArrayList<>();
	
	@GetMapping
	public  List<Product> getProduct(){
		return plist;
	}
	
	@PostMapping
	public ResponseEntity<?> postProduct(@Valid @RequestBody Product  product, BindingResult results){
	List <String>errors=new ArrayList<String>();
		if(results.hasErrors()) {
		for(FieldError error: results.getFieldErrors()) {
			errors.add(error.getField()+"  "+error.getDefaultMessage());
		}
		return ResponseEntity.badRequest().body(errors);		
	}
		else {
			plist.add(product);
			return ResponseEntity.ok(plist);
		}	
	
	}
	
	  @PutMapping
	    public ResponseEntity<?> putproduct(@Valid @RequestBody Product product, BindingResult results) {
	        if (results.hasErrors()) {
	            List<String> errors = new ArrayList<>();
	            for (FieldError error : results.getFieldErrors()) {
	                errors.add(error.getField() + " " + error.getDefaultMessage());
	            }
	            return ResponseEntity.badRequest().body(errors);
	        }

	        boolean updated = false;
	        for (Product p : plist) {
	            if (product.getId() == p.getId()) {
	                p.setName(product.getName());
	                p.setPrice(product.getPrice());
	                updated = true;
	                break;
	            }
	        }

	        if (updated) {
	            return ResponseEntity.ok(plist);
	        } else {
	            return ResponseEntity.status(404).body("Product not found");
	        }
	    }
	
	
	
    @DeleteMapping("/{id}")
    public List<Product>deleteProduct(@PathVariable int id){
    	for(Product p: plist) {
    		if(id==p.getId()) {
    			plist.remove(p);
    		}
    	}
    	return plist;
    }
    
  
}
