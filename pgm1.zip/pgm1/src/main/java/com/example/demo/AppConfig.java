package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
	public class AppConfig {
		@Bean
	    @Scope("prototype")
	    public Customer getCustomer() {
	        Customer c = new Customer();
	        c.setTick(ticket()); // Inject the ticket bean into the customer
	        return c;
	    }

	    @Bean
	    @Scope("prototype")
	    public Ticket ticket() {
	        return new Ticket();
	    }
		

	}



