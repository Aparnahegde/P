package com.example.demo;

public class Customer {
	
	private String name, adress;
	private Ticket Tick;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
  
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public Ticket getTick() {
		return Tick;
	}
	public void setTick(Ticket tick) {
		this.Tick = tick;
	}
}
