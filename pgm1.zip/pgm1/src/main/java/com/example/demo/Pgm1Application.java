package com.example.demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class Pgm1Application {

	public static void main(String[] args) {
		SpringApplication.run(Pgm1Application.class, args);
		
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        Scanner sc = new Scanner(System.in);

        // Retrieve Customer bean
        Customer cs = context.getBean(Customer.class);

        while (true) {
            System.out.println("\n1. Insert the details \n2. Display details \n3. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the customer name: ");
                    cs.setName(sc.next());
                    System.out.print("Enter the customer address: ");
                    cs.setAdress(sc.next());
                    Ticket t = cs.getTick();
                    System.out.print("Enter the ticket number: ");
                    t.setTicno(sc.nextInt());
                    System.out.print("Enter the ticket seat no: ");
                    t.setSeatno(sc.nextInt());
                    System.out.print("Enter the ticket price: ");
                    t.setPrice(sc.nextInt());
                    System.out.print("Enter ticket type - economic/gold/platinum: ");
                    t.setTicktype(sc.next());
                    cs.setTick(t);
                    System.out.println("Details inserted successfully!");
                    break;

                case 2:
                    System.out.println("Customer details:");
                    System.out.println("Name: " + cs.getName() + ", Address: " + cs.getAdress());
                    t = cs.getTick();
                    System.out.println("Ticket details:");
                    System.out.println("Number: " + t.getTicno() + ", Seat No: " + t.getSeatno() +
                            ", Price: " + t.getPrice() + ", Type: " + t.getTicktype());
                    break;

                case 3:
                    System.out.println("Exiting the program. Goodbye!");
                    sc.close();
                    context.close(); // Properly close the context
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
