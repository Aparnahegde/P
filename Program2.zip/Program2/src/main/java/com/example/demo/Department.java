package com.example.demo;

public class Department {


	int id;

	String name, descriptuon;

	

	College college;


	public Department(College college) {

		super();

		this.college = college;

	}


	public int getId() {

		return id;

	}


	public void setId(int id) {

		this.id = id;

	}


	public String getName() {

		return name;

	}


	public void setName(String name) {

		this.name = name;

	}


	public String getDescriptuon() {

		return descriptuon;

	}


	public void setDescriptuon(String descriptuon) {

		this.descriptuon = descriptuon;

	}


	public College getCollege() {

		return college;

	}


	public void setCollege(College college) {

		this.college = college;

	}


	@Override

	public String toString() {

		return "Department [id=" + id + ", name=" + name + ", descriptuon=" + descriptuon + "]";

	}

	

	

}
