package com.example.demo;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Program2Application {

public static void main(String[] args) {
SpringApplication.run(Program2Application.class, args);
Scanner sc = new Scanner(System.in);

ClassPathXmlApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
       Department dt = (Department) ac.getBean("department");

       while (true) {
           System.out.println("1. Insert the Department details \n2. Display Department with College details \n3. Exit");
           System.out.println("Enter the choice");

           int a = sc.nextInt();
           sc.nextLine();
           switch (a) {
               case 1:
                   System.out.println("Enter the Department name");
                   dt.setName(sc.nextLine());
                   System.out.println("Enter the department number");
                   dt.setId(sc.nextInt());
                   sc.nextLine(); // Consume the newline
                   System.out.println("Enter the Department description");
                   dt.setDescriptuon(sc.nextLine());
                   System.out.println("Thanks");
                   break;

               case 2:
                   System.out.println("Department details:");
                   System.out.println("Name: " + dt.getName() + " ID: " + dt.getId() + " Department Description: " + dt.getDescriptuon());
                   System.out.println("College details:");
                   College c = dt.getCollege();
                   System.out.println("College Name: " + c.getName());
                   System.out.println("College Address: " + c.getAdress());
                   break;

               case 3:
                   System.exit(0);
                   break;

               default:
                   System.out.println("Invalid choice. Please try again.");
                   break;
           }
       }
   }
}


