package com.example.demo;


import java.util.ArrayList;

import java.util.List;


import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


@RestController

@RequestMapping("/book")



public class BookController {

	List<Book> blist=new ArrayList<>();

	@GetMapping

	public List<Book> getBook(){

		return blist;

	}

	

	@PostMapping

	public List<Book> PostBook(@RequestBody Book book){

		blist.add(book);

		return blist;

	}

	

	@PutMapping("/{id}")

	public List<Book> PutBook(@PathVariable int id,@RequestBody Book book){

		blist.set(0, book);

		return blist;

	}

	

	@DeleteMapping("/{id}")

	public List<Book> DeleteBook(@PathVariable int id){

		if(id>=0&&id<blist.size())

		blist.remove(id);

		return blist;

	}

	

	

	

	


}
