package com.example.demo;

public class Book {

int id,year;

String author,title;

public int getId() {

	return id;

}

public void setId(int id) {

	this.id = id;

}

public int getYear() {

	return year;

}

public void setYear(int year) {

	this.year = year;

}

public String getAuthor() {

	return author;

}

public void setAuthor(String author) {

	this.author = author;

}

public String getTitle() {

	return title;

}

public void setTitle(String title) {

	this.title = title;

}

@Override

public String toString() {

	return "Book [id=" + id + ", year=" + year + ", author=" + author + ", title=" + title + "]";

}


}
