package com.example.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Prog1Application {


	

		public static void main(String[] args) {
			SpringApplication.run(Prog1Application.class, args);
//			AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(Appconfig.class);
			ClassPathXmlApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");

			Customer c = ac.getBean(Customer.class);
			Ticket t = ac.getBean(Ticket.class);
			
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter Customer Details: ");
			System.out.println("Name: ");
			c.setName(scanner.nextLine());
			
			System.out.println("Address: ");
			c.setAddress(scanner.nextLine());
			
			System.out.println("Enter ticket details: ");
			System.out.println("Ticket number: ");
			t.setTicno(scanner.nextInt());
			
			System.out.println("Price: ");
			t.setPrice(scanner.nextInt());
			
			System.out.println("Seat Number: ");
			t.setSeatno(scanner.nextInt());
			scanner.nextLine();
			
			System.out.println("Ticket type: ");
			t.setTictype(scanner.nextLine());
			
			System.out.println("Customer details: ");
			System.out.println("Customer name: "+c.getName());
			System.out.println("Customer address: "+c.getAddress());
			System.out.println("Ticket Details:");
			System.out.println("Ticket no: "+t.getTicno());
			System.out.println("Ticket Seat No: "+t.getSeatno());
			System.out.println("Ticket price: "+t.getPrice());
			System.out.println("Ticket Type: "+t.getTictype());
			
			System.out.println("End of Display");
			scanner.close();
			ac.close();	
			
	}

}
