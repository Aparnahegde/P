package com.example.lab;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class Appconfig {
	
	//<bean id="getTicket" class="com.example.prac_onelab.Ticket scope="prototype"/>
	@Bean
	@Scope("prototype")
	public Customer getCustomer() {
		Customer c = new Customer();
		c.setTick(getTicket());
		return c;
	}
	
	//<bean id="getTicket" class="com.example.prac_onelab.Customerr scope="singleton">
	//<property name="tick" reference="getTicket"/>
	//</bean>
	@Bean
	@Scope("singleton")
	public Ticket getTicket() {
		return new Ticket();
	}
}